﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Dal.Entities
{
    public class DeliveryType
    {
        public int IdDeliveryType { get; set; }
        public string TypeDelivery { get; set; }
    }
}
