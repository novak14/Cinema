﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Dal.Entities
{
    public class CartPlaces
    {
        public int IdCartFilm { get; set; }
        public int IdPlace { get; set; }
    }
}
