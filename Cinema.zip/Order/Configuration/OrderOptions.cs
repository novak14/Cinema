﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.Configuration
{
    public class OrderOptions
    {
        public string connectionString { get; set; }
    }
}
